Hello,
=> run cmd on this folder path
=> type "node app" and hit enter
=> copy the server url and paste it on any browser
=> click product page to load default product first.
=> click admin to add/update/delete of any product.


main features:
=> The LocalStorage System for Product Stores
=> The SessionStorage  for the Cart
=> Powered by  HTML, CSS, Bootstrap and JavaScript
=> Search by any keyword of Product Name/ Details/ Category 
=> Filtered By Categoty
=> Remove item from cart
=> Checkout for clear the cart.
=> if Quantity is 0 then Product will be Unavailable and Add to cart button will disapear on the product. if quantity and Aviability is update, then the Button will appear automatically.

Thank you.